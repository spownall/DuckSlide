package com.example.csromero.androidlabs;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.xmlpull.v1.XmlPullParser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static android.R.attr.value;

public class WeatherForecast extends AppCompatActivity {
    protected static final String ACTIVITY_NAME = "WeatherForecast";

    private TextView currentTemp;
    private TextView minTemp;
    private TextView maxTemp;
    private ImageView weatherImage;
    ProgressBar checkWeatherProgressBar;
    Button checkWeatherButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_forecast);

        // Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        // setSupportActionBar(toolbar);

        checkWeatherButton = (Button) findViewById(R.id.WeatherButton);
        checkWeatherProgressBar = (ProgressBar) findViewById(R.id.weatherProgressBar);

        currentTemp = (TextView) findViewById(R.id.currentTempView);
        minTemp = (TextView) findViewById(R.id.minTempView);
        maxTemp = (TextView) findViewById(R.id.maxTempView);
        weatherImage = (ImageView) findViewById(R.id.currentWeatherView);

        ForecastQuery forecast = new ForecastQuery();
        String urlString = "http://api.openweathermap.org/data/2.5/weather?q=ottawa,ca&APPID=d99666875e0e51521f0040a3d97d0f6a&mode=xml&units=metric";
        forecast.execute(urlString);

        checkWeatherProgressBar.setVisibility(View.VISIBLE);
    }

    public static Bitmap getImage(URL url) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            int responseCode = connection.getResponseCode();
            if (responseCode == 200) {
                return BitmapFactory.decodeStream(connection.getInputStream());
            } else
                return null;
        } catch (Exception e) {
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    public static Bitmap getImage(String urlString) {
        try {
            URL url = new URL(urlString);
            return getImage(url);
        } catch (MalformedURLException e) {
            return null;
        }
    }

    public boolean fileExistance(String fname) {
        File file = getBaseContext().getFileStreamPath(fname);
        return file.exists();
    }


    public class ForecastQuery extends AsyncTask<String, Integer, String> {
        //String urlString = "http://api.openweathermap.org/data/2.5/weather";
        //String urlString = "http://api.openweathermap.org/data/2.5/weather?q=ottawa,ca&APPID=d99666875e0e51521f0040a3d97d0f6a&mode=xml&units=metric";
        String minWeatherTemp;
        String maxWeatherTemp;
        String currentWeatherTemp;
        String currentWeatherIconName;
        Bitmap currentWeatherIcon;

        @Override
        protected String doInBackground(String... args) {
            // Given a string representation of a URL, sets up a connection and gets
            // an input stream.
            try {
                Log.i(ACTIVITY_NAME, "In doInBackground");

                URL url = new URL(args[0]);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                conn.connect();

                InputStream stream = conn.getInputStream();
                XmlPullParser parser = Xml.newPullParser();
                parser.setInput(stream, null);

                while (parser.next() != XmlPullParser.END_DOCUMENT) {
                    if (parser.getEventType() != XmlPullParser.START_TAG) {
                        continue;
                    }

                    if (parser.getName().equals("temperature")) {
                        currentWeatherTemp = parser.getAttributeValue(null, "value");
                        publishProgress(25);
                        minWeatherTemp = parser.getAttributeValue(null, "min");
                        publishProgress(50);
                        maxWeatherTemp = parser.getAttributeValue(null, "max");
                        publishProgress(75);
                    }
                    if (parser.getName().equals("weather")) {
                        currentWeatherIconName = parser.getAttributeValue(null, "icon");
                        String currentWeatherIconFile = currentWeatherIconName + ".png";
                        if (fileExistance(currentWeatherIconFile)) {
                            FileInputStream fis = null;
                            try {
                                fis = new FileInputStream(getBaseContext().getFileStreamPath(currentWeatherIconFile));
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            }
                            currentWeatherIcon = BitmapFactory.decodeStream(fis);
                            Log.i(ACTIVITY_NAME, "akh I think that image already exists bro");
                        } else {
                            URL imageURL = new URL("http://openweathermap.org/img/w/" + currentWeatherIconName + ".png");
                            Bitmap image = getImage(imageURL);
                            FileOutputStream outputStream = openFileOutput(currentWeatherIconName + ".png", Context.MODE_PRIVATE);
                            image.compress(Bitmap.CompressFormat.PNG, 80, outputStream);
                            outputStream.flush();
                            outputStream.close();
                        }
                        Log.i(ACTIVITY_NAME, "File Name: " + currentWeatherIconFile);
                        publishProgress(100);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... value) {
            Log.i(ACTIVITY_NAME, "We made it to onProgressUpdate");
            checkWeatherProgressBar.setVisibility(View.VISIBLE);
            checkWeatherProgressBar.setProgress(value[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            String degree = Character.toString((char) 0x00B0);
            currentTemp.setText(currentTemp.getText().toString() + currentTemp + degree + "C");
            minTemp.setText(minTemp.getText().toString() + minTemp + degree + "C");
            maxTemp.setText(maxTemp.getText().toString() + maxTemp + degree + "C");
            weatherImage.setImageBitmap(currentWeatherIcon);
            checkWeatherProgressBar.setVisibility(View.INVISIBLE);
        }
    }
}
