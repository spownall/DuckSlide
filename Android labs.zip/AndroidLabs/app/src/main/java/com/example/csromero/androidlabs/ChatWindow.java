package com.example.csromero.androidlabs;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class ChatWindow extends AppCompatActivity {

    ChatDatabaseHelper dbHelper;
    SQLiteDatabase db;
    ListView ChatListView;
    EditText ChatEditText;
    Button ChatSendButton;
    ArrayList<String> ChatTextList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_window);
        ChatListView = (ListView) findViewById(R.id.ChatListView);
        ChatEditText = (EditText) findViewById(R.id.editChatText);
        ChatSendButton = (Button) findViewById(R.id.SendButton);

        dbHelper = new ChatDatabaseHelper(this);

        db = dbHelper.getWritableDatabase();

        //gets all existing chat messages
        getAllMessages();

        //in this case, "this" is the ChatWindow, which is-A Context object
        final ChatAdapter messageAdapter = new ChatAdapter(this);
        ChatListView.setAdapter(messageAdapter);

        // this is the send button which the user presses to load their editText field into the array list/dtabase
        ChatSendButton.setOnClickListener(new View.OnClickListener() {
            // perform action on click
            public void onClick(View v) {
                System.out.println ("In onclick");
                if (ChatEditText.getText() != null) {
                    String chatLine = ChatEditText.getText().toString();
                    ChatTextList.add(chatLine);

                    messageAdapter.notifyDataSetChanged();//this restarts the process of getCount()/getView()
                    ChatEditText.setText("");

                    insertMessage(chatLine);
                }
            }
        });
    }

    public void insertMessage (String message){
        // add a message into the database
        ContentValues cValues = new ContentValues();
        cValues.put("message", message);
        db.insert(dbHelper.TABLE_NAME, "NullPlaceholder", cValues);
    }

     public void getAllMessages() {
        // construct an SQL statement to get all messages in database
        Cursor c = db.rawQuery("select * from " + dbHelper.TABLE_NAME, null);
        int colIndex = c.getColumnIndex(dbHelper.KEY_MESSAGE);

        c.moveToFirst();

         //Print information about the cursor
         for (int i = 0; i < c.getColumnCount(); i++) {
             Log.i((dbHelper.ACTIVITY_NAME), "Cursor’s current value = " + c.getColumnName(i));
         }
         while (!c.isAfterLast()){
            String me = c.getString(colIndex);
            System.out.println("Message: " + me);
            Log.i(dbHelper.ACTIVITY_NAME, "SQL MESSAGE:" +
                    c.getString(c.getColumnIndex(dbHelper.KEY_MESSAGE))
            );
            ChatTextList.add(me);
            c.moveToNext();
        }

        /*
    	Log.i(ACTIVITY_NAME, “Cursor’s  column count =” + cursor.getColumnCount() );
        Then use a for loop to print out the name of each column returned by the cursor. Use cursor.getColumnName(int columnIndex) to retrieve each column name.
         */
    }

    private class ChatAdapter extends ArrayAdapter<String> {

        public ChatAdapter(Context ctx) {
            super(ctx, 0);
        }


        public int getCount() {
            return ChatTextList.size();
        }

        public String getItem(int position) {
            return ChatTextList.get(position);
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            LayoutInflater inflater = ChatWindow.this.getLayoutInflater();
            View result = null;
            if (position % 2 == 0)
                result = inflater.inflate(R.layout.chat_row_incoming, null);
            else
                result = inflater.inflate(R.layout.chat_row_outgoing, null);

            TextView message = (TextView) result.findViewById(R.id.message_text);
            message.setText(getItem(position));//get the string at position
            return result;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //close database from onCreate
        db.close();
    }
}