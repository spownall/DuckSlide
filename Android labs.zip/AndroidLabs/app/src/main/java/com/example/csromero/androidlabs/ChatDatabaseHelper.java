package com.example.csromero.androidlabs;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.List;

import static android.R.attr.name;
import static android.os.FileObserver.CREATE;
import static android.provider.Contacts.SettingsColumns.KEY;

/**
 * Created by CSRomero on 05/03/2017.
 */

public class ChatDatabaseHelper extends SQLiteOpenHelper {


    public static String DATABASE_NAME = "Chats.db";
    public static int VERSION_NUM = 2;
    public final static String TABLE_NAME = "chatTable";
    public final static String ACTIVITY_NAME = "chatActivity";
    public final static String KEY_ID = "id";
    public final static String KEY_MESSAGE = "message";

    public ChatDatabaseHelper(Context ctx) {
        super(ctx, DATABASE_NAME, null, VERSION_NUM);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE " + TABLE_NAME + " (id integer primary key, message text);");
        Log.i("ChatDatabaseHelper", "Calling onCreate");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
        Log.i("ChatDatabaseHelper", "Calling onUpgrade, oldVersion=" + oldVer + " newVersion=" + newVer);
    }





    public int getVERSION_NUM() {
        return VERSION_NUM;
    }

    public String getDATABASE_NAME() {
        return DATABASE_NAME;
    }

}



